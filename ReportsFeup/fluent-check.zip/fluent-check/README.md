# FluentCheck

A property-based testing framework inspired by [FastCheck](https://github.com/dubzzz/fast-check) and focused on smarter
search strategies and statistical confidence calculation.
