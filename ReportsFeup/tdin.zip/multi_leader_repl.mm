<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1619679364691" ID="ID_494704411" MODIFIED="1622983770968" TEXT="multi-leader replication">
<node CREATED="1619291202417" ID="ID_1542431432" MODIFIED="1619291232362" POSITION="right" TEXT="leader-based replication has a major drawback">
<node CREATED="1619291232362" FOLDED="true" ID="ID_2482248" MODIFIED="1622982249747" TEXT="all updates are performed at the leader">
<node CREATED="1619291269122" ID="ID_1270209284" MODIFIED="1619291277758" TEXT="this is may be">
<node CREATED="1619291277759" FOLDED="true" ID="ID_465345859" MODIFIED="1622982245561" TEXT="a performance problem">
<node CREATED="1619291308865" ID="ID_1950873626" MODIFIED="1619291351398" TEXT="if there are too many update requests"/>
</node>
<node CREATED="1619291281849" FOLDED="true" ID="ID_164081247" MODIFIED="1622982246393" TEXT="an availability problem">
<node CREATED="1619291293186" ID="ID_570546324" MODIFIED="1619291306628" TEXT="if a client cannot reach the leader"/>
</node>
</node>
</node>
</node>
<node CREATED="1622982299079" ID="ID_452714766" MODIFIED="1622982305970" POSITION="right" TEXT="multi-leader replication">
<node CREATED="1619291392063" ID="ID_783359117" MODIFIED="1619291427545" TEXT="why not allow more than one node to perform writes?">
<node CREATED="1619291517778" ID="ID_1258447927" MODIFIED="1619291537529" TEXT="we&apos;ll call this multi-leader replication"/>
</node>
<node CREATED="1619291435667" FOLDED="true" ID="ID_258142519" MODIFIED="1622982330070" TEXT="replication still happens in the same way">
<node CREATED="1619291449775" ID="ID_184894315" MODIFIED="1619291498139" TEXT="each node that processes an update must &#xa;forward  that data change to the other nodes"/>
</node>
<node CREATED="1619291549092" ID="ID_164427775" MODIFIED="1619291583913" TEXT="each leader is also a follower to the other leaders"/>
</node>
<node CREATED="1619291606580" ID="ID_770011498" MODIFIED="1620146353938" POSITION="right" TEXT="Use cases for multi-leader replication">
<node CREATED="1619291727958" FOLDED="true" ID="ID_1497336154" MODIFIED="1622982741801" TEXT="multi-datacenter operation">
<node CREATED="1619291619916" ID="ID_1044178150" MODIFIED="1619291681650" TEXT="multi-leader replication seldom &#xa;makes sense in a single datacenter">
<node CREATED="1619291685542" ID="ID_386789106" MODIFIED="1619291716915" TEXT="the benefits rarely &#xa;outweight the complexity"/>
</node>
<node CREATED="1619291737492" FOLDED="true" ID="ID_68098677" MODIFIED="1622982410024" TEXT="replicas in several different datacenters">
<node CREATED="1619291765485" ID="ID_1427770374" MODIFIED="1619291784323" TEXT="to tolerate failure of an entire datacenter"/>
<node CREATED="1619291784782" ID="ID_1658556712" MODIFIED="1619291818283" TEXT="or for reducing latency for users in different locations"/>
</node>
<node CREATED="1619291831928" FOLDED="true" ID="ID_488265664" MODIFIED="1622982427381" TEXT="with single-leader replication">
<node CREATED="1619291859897" ID="ID_204653521" MODIFIED="1619291884009" TEXT="the leader will be in a data center"/>
<node CREATED="1619291885125" ID="ID_651412076" MODIFIED="1619291902871" TEXT="all update requests must go through that datacenter"/>
</node>
<node CREATED="1619291914513" ID="ID_451903160" MODIFIED="1622982461410" TEXT="in a multi-leader configuration">
<node CREATED="1619291924280" ID="ID_1251392613" LINK="fig_5_06.png" MODIFIED="1619291994106" TEXT="there may be a leader per datacenter"/>
<node CREATED="1619292014663" FOLDED="true" ID="ID_712690345" MODIFIED="1622982467613" TEXT="whithin each datacenter">
<node CREATED="1619292030630" ID="ID_196611089" MODIFIED="1619292041052" TEXT="regular leader-follower replication is used"/>
</node>
<node CREATED="1619292043431" FOLDED="true" ID="ID_1129478062" MODIFIED="1622982470118" TEXT="between datacenters">
<node CREATED="1619292049239" ID="ID_660724885" MODIFIED="1622982456893" TEXT="each datacenter&apos;s leader replicates its changes &#xa;to the leaders in other datacenters"/>
</node>
<node CREATED="1619292090850" ID="ID_882632790" MODIFIED="1622982505149" TEXT="essentially this is a hierarchical solution">
<node CREATED="1619292226648" ID="ID_1223946890" MODIFIED="1619292238758" TEXT="intra-datacenter replication"/>
<node CREATED="1619292239168" ID="ID_815897284" MODIFIED="1619292248145" TEXT="inter-datacenter replication"/>
</node>
</node>
<node CREATED="1619292286679" ID="ID_493698744" MODIFIED="1619292298053" TEXT="multi-leader vs. single leader">
<node CREATED="1619292313894" ID="ID_1581810146" MODIFIED="1619292331799" TEXT="in multi-datacenter deployments"/>
<node CREATED="1619292298053" FOLDED="true" ID="ID_1078897477" MODIFIED="1622982565590" TEXT="performance">
<node CREATED="1619292395516" ID="ID_300594607" MODIFIED="1619292422570" TEXT="single">
<node CREATED="1619292333706" ID="ID_1974770994" MODIFIED="1619292356671" TEXT="all writes must go over the internet to the datacenter of the leader"/>
<node CREATED="1619292362075" ID="ID_1407990783" MODIFIED="1619292374226" TEXT="this can add significant latency to writes"/>
</node>
<node CREATED="1619292423473" ID="ID_340739929" MODIFIED="1619292556175" TEXT="multi">
<node CREATED="1619292466844" ID="ID_1616136212" MODIFIED="1619292470420" TEXT="each write">
<node CREATED="1619292428385" ID="ID_1145979440" MODIFIED="1619292465358" TEXT="can be performed on the local datacenter"/>
<node CREATED="1619292471497" ID="ID_1571990967" MODIFIED="1622982547301" TEXT="propagated asynchronously to other data-centers"/>
</node>
<node CREATED="1619292556167" ID="ID_1583320107" MODIFIED="1619292556167" TEXT="">
<node CREATED="1619292518829" ID="ID_1116200772" MODIFIED="1619292554339" TEXT="the inter-datacenter network delay is hidden from users"/>
<node CREATED="1619292557567" ID="ID_913159389" MODIFIED="1619292566959" TEXT="the perceived perfomance may be better"/>
</node>
</node>
</node>
<node CREATED="1619292571332" FOLDED="true" ID="ID_551016167" MODIFIED="1622982681653" TEXT="tolerance to datacenter outages">
<node CREATED="1619292583619" ID="ID_646285541" MODIFIED="1619292605285" TEXT="single">
<node CREATED="1619292605286" ID="ID_1029104370" MODIFIED="1619292618179" TEXT="if the datacenter with the leader fals"/>
<node CREATED="1619292618916" ID="ID_263988984" MODIFIED="1620024915552" TEXT="failover can promote a gollower in another datacenter to be tleader"/>
</node>
<node CREATED="1619292638334" ID="ID_1076738954" MODIFIED="1619292640629" TEXT="multi">
<node CREATED="1619292758769" ID="ID_1246718382" MODIFIED="1619292767060" TEXT="if a datacenter fails"/>
<node CREATED="1619292645484" ID="ID_436928067" MODIFIED="1619292778422" TEXT="other datacenter can continue to operate as before">
<node CREATED="1619292778422" ID="ID_1623510764" MODIFIED="1619292783742" TEXT="no need for reconfiguration"/>
</node>
<node CREATED="1619292696781" ID="ID_1397968637" MODIFIED="1619292728902" TEXT="when the failed datacenter comes back online it will catch up"/>
</node>
</node>
<node CREATED="1619292794672" FOLDED="true" ID="ID_440395458" MODIFIED="1622982686156" TEXT="tolerance to network problems">
<node CREATED="1619292827331" ID="ID_777596329" MODIFIED="1619292830234" TEXT="single">
<node CREATED="1619292830234" ID="ID_1368265442" MODIFIED="1619293051395" TEXT="if inter-datacenter replication is synchronous"/>
<node CREATED="1619292888538" ID="ID_1632429876" MODIFIED="1619292991438" TEXT="very sensitive to network problems between datacenters">
<node CREATED="1619293064135" ID="ID_709247099" MODIFIED="1619293072739" TEXT="writing may become unavailable"/>
</node>
</node>
<node CREATED="1619292935269" ID="ID_1567751063" MODIFIED="1619292939976" TEXT="multi">
<node CREATED="1619292939976" ID="ID_502240442" MODIFIED="1619292953156" TEXT="less sensistive"/>
<node CREATED="1619292995481" ID="ID_613869354" MODIFIED="1619293015866" TEXT="inter-datacenter replication is asynchronous"/>
</node>
</node>
</node>
<node CREATED="1619293093247" ID="ID_1229251383" MODIFIED="1620146686599" TEXT="some databases support multi-leader configurations">
<node CREATED="1619293113882" ID="ID_1005208871" MODIFIED="1619293128077" TEXT="but it is also often implemented with external tools"/>
<node CREATED="1619293128593" ID="ID_500624454" MODIFIED="1619293134347" TEXT="e.g.">
<node CREATED="1619293134348" ID="ID_1173240514" MODIFIED="1619293153281" TEXT="MySQL">
<node CREATED="1619293137815" ID="ID_864581994" MODIFIED="1619293148355" TEXT="Tungsten Replicator"/>
</node>
<node CREATED="1619293154582" ID="ID_231786535" MODIFIED="1619293187259" TEXT="PostgreSQL">
<node CREATED="1619293161648" ID="ID_1300514419" MODIFIED="1619293163595" TEXT="BDR"/>
</node>
<node CREATED="1619293171497" ID="ID_549190664" MODIFIED="1619293175549" TEXT="Oracle">
<node CREATED="1619293175550" ID="ID_173090563" MODIFIED="1619293181811" TEXT="GoldenGate"/>
</node>
</node>
</node>
<node CREATED="1619293502247" ID="ID_629183342" MODIFIED="1619293507146" TEXT="downside">
<node CREATED="1619293507146" ID="ID_798775379" MODIFIED="1619293527245" TEXT="the same data may be concurrently modified at two different datacenters">
<node CREATED="1619293531620" ID="ID_1557950120" MODIFIED="1620024974724" TEXT="those writes must be resolved."/>
</node>
<node CREATED="1619328662884" ID="ID_1087464813" MODIFIED="1619328734678" TEXT="in the case of DB it does not play well with some features such as">
<node CREATED="1619328693215" ID="ID_1928363705" MODIFIED="1619328700367" TEXT="autoincrementing keys"/>
<node CREATED="1619328700870" ID="ID_614932095" MODIFIED="1619328703441" TEXT="triggers"/>
<node CREATED="1619328704079" ID="ID_1840801713" MODIFIED="1619328713131" TEXT="integrity constraints"/>
</node>
</node>
</node>
<node CREATED="1619328798253" FOLDED="true" ID="ID_1685443821" MODIFIED="1622983190693" TEXT="clients with offline operation">
<node CREATED="1619328823202" ID="ID_828860286" MODIFIED="1622982752441" TEXT="i.e. applications that need to continue to work &#xa;while they are disconnected from the internet">
<node CREATED="1619328882392" FOLDED="true" ID="ID_1117377518" MODIFIED="1622983180465" TEXT="calendar app">
<node CREATED="1619328907265" ID="ID_935406988" MODIFIED="1619328915437" TEXT="need to">
<node CREATED="1619328915437" ID="ID_1213046247" MODIFIED="1619328929263" TEXT="check meetings ">
<node CREATED="1619328929263" ID="ID_1156029866" MODIFIED="1619328936662" TEXT="i.e. make read requests"/>
</node>
<node CREATED="1619328939669" ID="ID_1544264154" MODIFIED="1619328947882" TEXT="enter new meetings">
<node CREATED="1619328947883" ID="ID_1873512993" MODIFIED="1619328959235" TEXT="i.e. make write requests"/>
</node>
<node CREATED="1619328961211" ID="ID_732171623" MODIFIED="1619328964857" TEXT="any time">
<node CREATED="1619328964858" ID="ID_1726954328" MODIFIED="1620025018148" TEXT="regardless of whether the device has an internet connection"/>
</node>
</node>
<node CREATED="1619329018158" ID="ID_1018564939" MODIFIED="1619329089425" TEXT="changes performed while offline will be synced &#xa;with the server and other devices &#xa;when the device reconnects"/>
<node CREATED="1619329101926" ID="ID_1055695241" MODIFIED="1622982892144" TEXT="in this case">
<node CREATED="1622982892139" ID="ID_113040308" MODIFIED="1622982895951" TEXT="every device">
<node CREATED="1619329107382" ID="ID_595272043" MODIFIED="1622982901527" TEXT="has a local DB"/>
<node CREATED="1619329135505" ID="ID_1087220355" MODIFIED="1619329142438" TEXT="acts as leader">
<node CREATED="1619329142442" ID="ID_323264848" MODIFIED="1619329153279" TEXT="accepts write requests"/>
</node>
<node CREATED="1622983061150" ID="ID_895446089" MODIFIED="1622983080394" TEXT="uses asynchronous replication">
<node CREATED="1619329217313" ID="ID_394861855" MODIFIED="1619329255025" TEXT="between the replicas of the calendar app on all user&apos;s devices"/>
</node>
</node>
<node CREATED="1619329259071" ID="ID_488844037" MODIFIED="1619329270358" TEXT="the replication lag may be">
<node CREATED="1619329270359" ID="ID_874135049" MODIFIED="1619329272248" TEXT="hours"/>
<node CREATED="1619329272527" ID="ID_426743747" MODIFIED="1619329275446" TEXT="or even days"/>
</node>
</node>
<node CREATED="1619329342745" ID="ID_51873233" MODIFIED="1619329394765" TEXT="this can be considered an extreme &#xa;case of multi-leader replication">
<node CREATED="1619329376121" ID="ID_1096345669" MODIFIED="1619329431438" TEXT="in which the network connection is extremely unreliable"/>
</node>
</node>
<node CREATED="1619329326617" ID="ID_697283289" MODIFIED="1619329470526" TEXT="CouchDB is a storage library designed for this mode of operation"/>
</node>
</node>
<node CREATED="1619329496007" FOLDED="true" ID="ID_1943979989" MODIFIED="1622983305439" TEXT="collaborative editing">
<node CREATED="1619329521371" ID="ID_635360459" MODIFIED="1619329553274" TEXT="allows several people to edit a document simultaneously">
<node CREATED="1619329555443" ID="ID_150409928" MODIFIED="1619329563639" TEXT="e.g. Google Docs"/>
</node>
<node CREATED="1619329584594" ID="ID_1031566762" MODIFIED="1619329596497" TEXT="when a user edits a document">
<node CREATED="1619329596498" ID="ID_1481306621" MODIFIED="1619329611146" TEXT="the changes are instantly applied to their local replica"/>
<node CREATED="1619329614173" ID="ID_1493814849" MODIFIED="1619329636061" TEXT="and asynchronously replicated to">
<node CREATED="1619329636062" ID="ID_1940530344" MODIFIED="1619329638628" TEXT="the server"/>
<node CREATED="1619329639093" ID="ID_1137080657" MODIFIED="1619329649579" TEXT="and any other uswers who are editing the same document"/>
</node>
</node>
<node CREATED="1619329703809" ID="ID_1828270403" MODIFIED="1620025071945" TEXT="to guarantee that there are no editing conflicts">
<node CREATED="1619329731032" ID="ID_1004120745" MODIFIED="1619329764827" TEXT="the application must acquire a lock">
<node CREATED="1619329764827" ID="ID_1539107810" MODIFIED="1619329772248" TEXT="before a user can edit it"/>
</node>
<node CREATED="1619329835456" ID="ID_826908167" MODIFIED="1619329859378" TEXT="if another user wants to edit the same document">
<node CREATED="1619329859379" ID="ID_1658831015" MODIFIED="1619329882804" TEXT="they have to wait until">
<node CREATED="1619329882804" ID="ID_676256073" MODIFIED="1619329891858" TEXT="the first user">
<node CREATED="1619329891858" ID="ID_255578739" MODIFIED="1619329900846" TEXT="has committed their changes"/>
<node CREATED="1619329901312" ID="ID_1266772405" MODIFIED="1619329906485" TEXT="and released the lock"/>
</node>
</node>
</node>
<node CREATED="1619329813261" ID="ID_1790030843" MODIFIED="1619329833751" TEXT="this operation mode is similar to single-leader replication"/>
<node CREATED="1619329918458" ID="ID_233086021" MODIFIED="1619329930793" TEXT="for faster collaboration">
<node CREATED="1619329930793" ID="ID_164446550" MODIFIED="1619329970161" TEXT="one can make the granularity of change very small">
<node CREATED="1619329970162" ID="ID_1836629030" MODIFIED="1619329976161" TEXT="e.g. a single keystroke"/>
</node>
<node CREATED="1619329978803" ID="ID_1439046216" MODIFIED="1619329983368" TEXT="and avoid locking"/>
<node CREATED="1619329996045" ID="ID_1504225814" MODIFIED="1619330015282" TEXT="this allows multiple users to edit simultaneously"/>
<node CREATED="1619330016185" ID="ID_1066434391" MODIFIED="1619330042521" TEXT="but has essentially the same challenges as multi-leader replication"/>
</node>
</node>
</node>
</node>
<node CREATED="1619330082132" ID="ID_1791151254" MODIFIED="1622990147030" POSITION="right" TEXT="Handling Write Conflicts">
<node CREATED="1619332480706" ID="ID_1953670813" MODIFIED="1622983363756" TEXT="this is the major issue with multi-leader replication">
<node CREATED="1619332523153" ID="ID_819288765" MODIFIED="1622983336531" TEXT="e.g.">
<node CREATED="1619332531413" ID="ID_328486974" LINK="fig_5_07.png" MODIFIED="1619333763153" TEXT="simultaneous editing of a wiki page">
<linktarget COLOR="#eeeeee" DESTINATION="ID_328486974" ENDARROW="Default" ENDINCLINATION="340;0;" ID="Arrow_ID_1874367690" SOURCE="ID_1315911832" STARTARROW="None" STARTINCLINATION="340;0;"/>
</node>
<node CREATED="1619332727764" ID="ID_39628786" MODIFIED="1619332758841" TEXT="conflict is detected when changes are asynchronously replicated"/>
</node>
</node>
<node CREATED="1619332494494" ID="ID_1736494512" MODIFIED="1619332510898" TEXT="need conflict resolution"/>
<node CREATED="1619332776975" FOLDED="true" ID="ID_62520215" MODIFIED="1622990011001" TEXT="conflict detection">
<node CREATED="1619332801898" FOLDED="true" ID="ID_159965065" MODIFIED="1622983546957" TEXT="with single-leader replication">
<node CREATED="1619332810803" ID="ID_1502869646" MODIFIED="1622983460727" TEXT="the second writer will">
<node CREATED="1619332818892" ID="ID_505447010" MODIFIED="1622983456742" TEXT="either block and wait for the first write to complete"/>
<node CREATED="1619332837299" FOLDED="true" ID="ID_1538204232" MODIFIED="1622983476442" TEXT="or abort the second write">
<node CREATED="1619332855238" ID="ID_1545213144" MODIFIED="1619332862963" TEXT="forcing the user to retry the write"/>
</node>
</node>
</node>
<node CREATED="1619332869429" ID="ID_1216502537" MODIFIED="1622983564253" TEXT="with multi-leader replication">
<node CREATED="1619332876568" FOLDED="true" ID="ID_1866980168" MODIFIED="1622983578636" TEXT="both writes may be successful">
<node CREATED="1619332885560" ID="ID_1063152576" MODIFIED="1619332905057" TEXT="conflict is detected asynchronously at some later point in time"/>
<node CREATED="1619332909157" ID="ID_1840513210" MODIFIED="1619332925804" TEXT="at that time it may be too late to ask the user to resolve the conflict"/>
</node>
<node CREATED="1619332946879" FOLDED="true" ID="ID_132267196" MODIFIED="1622983575633" TEXT="conflict detection might be synchronous">
<node CREATED="1619332962233" ID="ID_1866049589" MODIFIED="1619332970875" TEXT="i.e.">
<node CREATED="1619332970876" ID="ID_1086877050" MODIFIED="1619332985149" TEXT="wait for the write to be replicated to all replicas"/>
<node CREATED="1619332985849" ID="ID_438295388" MODIFIED="1619333002908" TEXT="before telling the user that the write was successful"/>
</node>
<node CREATED="1619333013988" ID="ID_144278268" MODIFIED="1619333057499" TEXT="but this would defeat the main advantage of multi-leader replication">
<node CREATED="1619333057499" ID="ID_1785517360" MODIFIED="1619333082517" TEXT="allowing each replica to accept writes independently"/>
</node>
<node CREATED="1619333101744" ID="ID_1557299451" MODIFIED="1619333118923" TEXT="if you want synchronous conflict detection">
<node CREATED="1619333118923" ID="ID_1220898299" MODIFIED="1619333136024" TEXT="you might as well use single-leader replication"/>
</node>
</node>
</node>
</node>
<node CREATED="1619333172156" FOLDED="true" ID="ID_1287757034" MODIFIED="1622990012391" TEXT="conflict avoidance">
<node CREATED="1619333178789" ID="ID_303111933" MODIFIED="1620153839450" TEXT="this is the simplest strategy for dealing with confllicts"/>
<node CREATED="1619333228449" ID="ID_1531455550" MODIFIED="1619333231170" TEXT="e.g.">
<node CREATED="1619333231171" ID="ID_1706342247" MODIFIED="1619333254006" TEXT="force that all writes for a particular data item go through the same leader"/>
<node CREATED="1619333264724" FOLDED="true" ID="ID_1773857555" MODIFIED="1622983618841" TEXT="consider an application where a user can edit own data">
<node CREATED="1619333288791" ID="ID_744389230" MODIFIED="1619333333315" TEXT="route requests from a particular user to the same datacenter"/>
<node CREATED="1619333337144" ID="ID_1121941760" MODIFIED="1619333363672" TEXT="which would be the leader for those requests"/>
<node CREATED="1619333365798" ID="ID_1413645767" MODIFIED="1619333379614" TEXT="different users may hae different &quot;home&quot; datacenters"/>
</node>
<node CREATED="1619333413952" FOLDED="true" ID="ID_1228877050" MODIFIED="1622983620176" TEXT="but this does not always work">
<node CREATED="1619333424044" ID="ID_1815956352" MODIFIED="1619333442207" TEXT="e.g. the datacenter may have failed or be unreachable"/>
<node CREATED="1619333451394" ID="ID_17010163" MODIFIED="1619333474168" TEXT="or the user was moved to a different location">
<node CREATED="1619333474168" ID="ID_1982352676" MODIFIED="1619333509702" TEXT="if users are assigned datacenters that are geographically closer"/>
</node>
<node CREATED="1619333542881" ID="ID_1677220140" MODIFIED="1619333562270" TEXT="one still needs to deal with the possibility of concurrent writes on different leaders"/>
</node>
</node>
</node>
<node CREATED="1619333621739" FOLDED="true" ID="ID_401895007" MODIFIED="1622990029286" TEXT="converging toward a consisten state">
<node CREATED="1619333631792" ID="ID_1467506487" MODIFIED="1620154108977" TEXT="in single leader replication">
<node CREATED="1619333647180" ID="ID_146932933" MODIFIED="1619333656353" TEXT="the leader decides the update order"/>
</node>
<node CREATED="1619335124606" ID="ID_1119542338" MODIFIED="1620154124442" TEXT="in multi-leader replication">
<node CREATED="1619333681972" ID="ID_294712991" MODIFIED="1619333694748" TEXT="there is no clear odering of writes"/>
<node CREATED="1619333713226" ID="ID_1451913123" MODIFIED="1619333729212" TEXT="it is not clear what the final value should be"/>
</node>
<node CREATED="1619333733798" ID="ID_1315911832" LINK="fig_5_07.png" MODIFIED="1622989588384" TEXT="e.g. consider the previous example">
<arrowlink DESTINATION="ID_328486974" ENDARROW="Default" ENDINCLINATION="340;0;" ID="Arrow_ID_1874367690" STARTARROW="None" STARTINCLINATION="340;0;"/>
<node CREATED="1619333800198" ID="ID_1214078158" MODIFIED="1622989602480" TEXT="if each replica applies the writes in the order it sees them"/>
<node CREATED="1619333821631" ID="ID_738345073" MODIFIED="1619333841017" TEXT="then each replica will end up with a different value">
<node CREATED="1619333845282" ID="ID_1126793269" MODIFIED="1619333869665" TEXT="i.e. the system will be inconsistent."/>
</node>
<node CREATED="1619333874003" ID="ID_201374443" MODIFIED="1619333888671" TEXT="this is not acceptable">
<node CREATED="1619333888671" ID="ID_339897665" MODIFIED="1619334431800" TEXT="every replication scheme must ensure that &#xa;the state is eventually the same in every replica"/>
</node>
</node>
<node CREATED="1619334464998" ID="ID_393309543" MODIFIED="1620154160493" TEXT="some alternatives">
<node CREATED="1619334469791" FOLDED="true" ID="ID_811672860" MODIFIED="1622989670497" TEXT="give each write a unique ID">
<node CREATED="1619334486021" ID="ID_1831722493" MODIFIED="1619334519655" TEXT="e.g.">
<node CREATED="1619334490979" ID="ID_1213259848" MODIFIED="1619334493836" TEXT="timestamp"/>
<node CREATED="1619334494377" ID="ID_226991224" MODIFIED="1619334554093" TEXT="long pseudo-random number">
<node CREATED="1619334539902" ID="ID_1756193550" MODIFIED="1619334541595" TEXT="UUID"/>
<node CREATED="1619334542049" ID="ID_645306086" MODIFIED="1619334548147" TEXT="hash value"/>
</node>
</node>
<node CREATED="1619334565931" ID="ID_1328978400" MODIFIED="1619334578794" TEXT="pick the write with the highest ID as the winner">
<node CREATED="1619334590280" ID="ID_1979543764" MODIFIED="1619334606379" TEXT="if a timestamp is used this scheme is known as">
<node CREATED="1619334606379" ID="ID_1273711417" MODIFIED="1622989633108" TEXT="last write wins (LWW)">
<font BOLD="true" NAME="SansSerif" SIZE="16"/>
</node>
</node>
</node>
<node CREATED="1619334658049" ID="ID_1360280566" MODIFIED="1619334671630" TEXT="this is relatively easy to implement">
<node CREATED="1619334671630" ID="ID_311990769" MODIFIED="1619334684625" TEXT="but it is a blunt approach"/>
</node>
</node>
<node CREATED="1619334696849" FOLDED="true" ID="ID_1797771718" MODIFIED="1622989672364" TEXT="give each replica a unique ID">
<node CREATED="1619334708517" ID="ID_601037289" MODIFIED="1619334741703" TEXT="give precedence to the writes adopted at the lowest numbered replica"/>
<node CREATED="1619334748553" ID="ID_1191052324" MODIFIED="1619334777693" TEXT="this has essentially the same issues as the previous"/>
</node>
<node CREATED="1619334788662" FOLDED="true" ID="ID_1093226085" MODIFIED="1622989675592" TEXT="merge the values together">
<node CREATED="1619334803307" ID="ID_1048373600" MODIFIED="1619334815756" TEXT="e.g. in the example above">
<node CREATED="1619334815756" ID="ID_379511349" MODIFIED="1619334844139" TEXT="order the names alphabetically"/>
<node CREATED="1619334851901" ID="ID_1541137967" MODIFIED="1620025589182" TEXT="and concatenate them">
<node CREATED="1620025589176" ID="ID_750426181" MODIFIED="1620025589176" TEXT="">
<node CREATED="1619334919135" ID="ID_1958373412" MODIFIED="1620025587329" TEXT="we could just pick the smallest name"/>
<node CREATED="1620025566640" ID="ID_633457730" MODIFIED="1620025577098" TEXT="but then this would not be an example of merging"/>
</node>
</node>
</node>
</node>
<node CREATED="1619334972673" ID="ID_610165926" MODIFIED="1622989734629" TEXT="record the conflict">
<icon BUILTIN="idea"/>
<node CREATED="1619334989214" ID="ID_942563576" MODIFIED="1619334998363" TEXT="in an explicit data structure">
<node CREATED="1619334998363" ID="ID_543689136" MODIFIED="1619335006267" TEXT="with the required information"/>
</node>
<node CREATED="1619335008270" ID="ID_126594521" MODIFIED="1619335029272" TEXT="write application code that resolves the conflict at some later time">
<node CREATED="1619335029272" ID="ID_1651070059" MODIFIED="1619335036006" TEXT="perhaps prompting the user"/>
</node>
</node>
</node>
</node>
<node CREATED="1619335151917" FOLDED="true" ID="ID_521380130" MODIFIED="1622990033047" TEXT="custom conflict resolution logic">
<node CREATED="1619335177091" ID="ID_1752390599" MODIFIED="1622989805114" TEXT="often the most appropriate way of resolving &#xa;a conflict is application dependent"/>
<node CREATED="1619335208482" ID="ID_1590971854" MODIFIED="1619335273393" TEXT="most multi-leader replication tools support &#xa;application-dependent code for conflict resolution"/>
<node CREATED="1619335274284" ID="ID_1618419369" MODIFIED="1619335289072" TEXT="this code may be executed">
<node CREATED="1619335289072" FOLDED="true" ID="ID_1260392364" MODIFIED="1622989893975" TEXT="upon writes">
<node CREATED="1619335300371" ID="ID_1573168452" MODIFIED="1619335665069" TEXT="as soon as the replication tool detects &#xa;a conflict in the log of replicated changes &#xa;it calls the conflict handler"/>
<node CREATED="1619335377574" ID="ID_1273082925" MODIFIED="1619335392410" TEXT="usually, the handler cannot prompt the user"/>
</node>
<node CREATED="1619335398702" ID="ID_1693567797" MODIFIED="1622989897100" TEXT="upon read">
<node CREATED="1619335404788" ID="ID_1740887754" MODIFIED="1619335415499" TEXT="when a conflict is detected">
<node CREATED="1619335415499" ID="ID_1383358298" MODIFIED="1619335423416" TEXT="all the conflicting writes are stored"/>
</node>
<node CREATED="1619335425649" ID="ID_918927326" MODIFIED="1619335444840" TEXT="the next time the data is read">
<node CREATED="1619335444840" ID="ID_576406167" MODIFIED="1620025675601" TEXT="the multiple versions of the data are returned to the application"/>
</node>
<node CREATED="1619335493247" ID="ID_14272845" MODIFIED="1619335503221" TEXT="the application may">
<node CREATED="1619335503221" ID="ID_554019242" MODIFIED="1619335511566" TEXT="prompt the user"/>
<node CREATED="1619335513411" ID="ID_1145686273" MODIFIED="1619335528312" TEXT="automatically resolve the conflict"/>
<node CREATED="1619335530087" ID="ID_1113946776" MODIFIED="1622989878630" TEXT="in either case">
<node CREATED="1619335535739" ID="ID_299684235" MODIFIED="1619335639726" TEXT="the replicated state is updated with the value &#xa;determined by conflict resolution"/>
</node>
</node>
<node CREATED="1619335672651" ID="ID_1641274325" MODIFIED="1619335676859" TEXT="example">
<node CREATED="1619335676859" HGAP="7" ID="ID_1524114979" MODIFIED="1620154634774" TEXT="CouchDB"/>
</node>
</node>
</node>
<node CREATED="1619335703409" ID="ID_1673359848" MODIFIED="1619335712746" TEXT="note that">
<node CREATED="1619335712747" ID="ID_1043919234" MODIFIED="1619335717208" TEXT="in the case of DBs"/>
<node CREATED="1619335718577" ID="ID_1191583735" MODIFIED="1619335761160" TEXT="conflict resolution is usually applied ">
<node CREATED="1619335761161" ID="ID_1517698616" MODIFIED="1619335766340" TEXT="to conflict updates"/>
<node CREATED="1619335766740" ID="ID_180244527" MODIFIED="1619335772609" TEXT="not the entire transaction"/>
</node>
</node>
</node>
<node CREATED="1619335945113" FOLDED="true" ID="ID_1905320727" MODIFIED="1622990151477" TEXT="automatic conflict resolution">
<node CREATED="1619335957193" ID="ID_1627912899" MODIFIED="1620156139020" TEXT="conflict resolution rules can quickly become complicated">
<node CREATED="1619335993986" ID="ID_307625894" MODIFIED="1619336002556" TEXT="and custom code can be error-prone"/>
<node CREATED="1619336009678" FOLDED="true" ID="ID_1039285426" MODIFIED="1622990051320" TEXT="e.g. the conflict resolution logic on Amazon&apos;s shopping cart ">
<node CREATED="1619336036767" ID="ID_338573943" MODIFIED="1619336046463" TEXT="would preserve items added to the cart"/>
<node CREATED="1619336047267" ID="ID_1602485052" MODIFIED="1619336058279" TEXT="but not items removed from the cart"/>
<node CREATED="1619336059062" ID="ID_1894499965" MODIFIED="1619336063070" TEXT="thus ">
<node CREATED="1619336063070" ID="ID_629257629" MODIFIED="1619336079413" TEXT="customers would seometimes see items reappering in their carts"/>
<node CREATED="1619336101361" ID="ID_437128350" MODIFIED="1619336123004" TEXT="even though they had previously been removed"/>
</node>
</node>
</node>
<node CREATED="1619336134837" ID="ID_322399246" MODIFIED="1620156103653" TEXT="some interesting research &#xa;for automatically resolving conflicts &#xa;caused by concurrent updates">
<node CREATED="1619336216373" FOLDED="true" ID="ID_123714501" MODIFIED="1622990049076" TEXT="conflict-free replicated datatypes (CRDTs)">
<node CREATED="1619336271114" ID="ID_1505022451" MODIFIED="1619336278359" TEXT="set of data structures for">
<node CREATED="1619336278360" ID="ID_1088044022" MODIFIED="1619336280193" TEXT="sets"/>
<node CREATED="1619336280780" ID="ID_1833533575" MODIFIED="1619336282337" TEXT="maps"/>
<node CREATED="1619336282802" ID="ID_1452054513" MODIFIED="1619336286940" TEXT="ordered lists"/>
</node>
<node CREATED="1619336291149" ID="ID_717204759" MODIFIED="1619336300851" TEXT="that can be concurrently edited by multiple users"/>
<node CREATED="1619336303329" ID="ID_1052645173" MODIFIED="1619336328910" TEXT="and that resolve conflicts automatically in sensible ways"/>
<node CREATED="1619336332459" ID="ID_1605032559" MODIFIED="1619336344495" TEXT="Riak 2.0 implements some of them"/>
<node CREATED="1620027150638" ID="ID_1563343436" MODIFIED="1620027159852" TEXT="and now PostgresSQL too"/>
</node>
<node CREATED="1619336349140" FOLDED="true" ID="ID_1719677653" MODIFIED="1622990057227" TEXT="mergeable persistent data structures">
<node CREATED="1619336382219" ID="ID_1670628781" MODIFIED="1619336391216" TEXT="track history explicitly">
<node CREATED="1619336391216" ID="ID_230935580" MODIFIED="1619336396371" TEXT="similarly to Git"/>
</node>
<node CREATED="1620750940995" ID="ID_19330110" MODIFIED="1622990000166" TEXT="not covered in TDIN"/>
</node>
<node CREATED="1619336421116" ID="ID_714056805" MODIFIED="1619336431354" TEXT="operational transformations">
<node CREATED="1619336431354" ID="ID_203656685" MODIFIED="1619336458219" TEXT="is a resolution algoritm behind collaborative editing applications"/>
<node CREATED="1619336464234" ID="ID_1108228460" MODIFIED="1619336499224" TEXT="it was designed for concurrent editing of an odered list of items, such as the sequence of characters that constitute a text document"/>
</node>
</node>
<node CREATED="1619336510218" ID="ID_309116605" MODIFIED="1619336543459" TEXT="these algorithms are relatively recent">
<node CREATED="1619336543459" ID="ID_1106588048" MODIFIED="1619336580963" TEXT="and have not yet found their way to many replication tools"/>
<node CREATED="1619336583903" ID="ID_1141034466" MODIFIED="1619336619766" TEXT="but they have the potential to make multi-leader &#xa;data synchronization much simpler for applications"/>
</node>
</node>
<node CREATED="1619336626563" FOLDED="true" ID="ID_1163948280" MODIFIED="1622990190442" TEXT="what is a conflict?">
<node CREATED="1619336649563" ID="ID_1654017697" MODIFIED="1619336659326" TEXT="some kinds of conflicts are obvious">
<node CREATED="1619336659327" ID="ID_611758970" MODIFIED="1620751056943" TEXT="e.g. two writes concurrently to the same&#xa; variable setting it to two different values"/>
</node>
<node CREATED="1619336697002" ID="ID_600752761" MODIFIED="1619336716249" TEXT="but other kinds of conflicts are not so obvious">
<node CREATED="1619336716250" ID="ID_1335422308" MODIFIED="1619336724461" TEXT="e.g. ">
<node CREATED="1619336724462" ID="ID_470635236" MODIFIED="1619336733072" TEXT="in a meeting room booking system">
<node CREATED="1619336739334" ID="ID_267812211" MODIFIED="1619336780929" TEXT="tracks which room is booked">
<node CREATED="1619336756606" ID="ID_1066571407" MODIFIED="1619336762055" TEXT="by which group of people"/>
<node CREATED="1619336762484" ID="ID_551008083" MODIFIED="1619336767692" TEXT="at which time"/>
</node>
<node CREATED="1619336782718" ID="ID_254192426" MODIFIED="1619336830721" TEXT="this application needs to ensure that each room &#xa;is booked by one group of people at any one time">
<node CREATED="1619336834823" ID="ID_276040608" MODIFIED="1620751126538" TEXT="i.e. there must not be any overlapping &#xa;bookings for the same room"/>
</node>
<node CREATED="1619336858152" ID="ID_1838192232" MODIFIED="1619336866450" TEXT="in this case">
<node CREATED="1619336866451" ID="ID_1669159429" MODIFIED="1619336879995" TEXT="a conflict may arise if">
<node CREATED="1619336879995" ID="ID_1024916080" MODIFIED="1620751182468">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      two different bookings are created for
    </p>
    <p>
      the same room overlapping in time
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
