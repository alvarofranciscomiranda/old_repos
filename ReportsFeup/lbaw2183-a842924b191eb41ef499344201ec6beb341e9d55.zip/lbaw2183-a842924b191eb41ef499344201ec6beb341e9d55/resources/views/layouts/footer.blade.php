<div id="footer-spacer">
</div>
<footer class="text-center text-white fixed-bottom scroll bg-secondary">
    <div class=" d-flex p-2 justify-content-around">
        Copyright &copy; 2022
        <span>Being with friends was never this easy</span>
        <a class="text-white btn btn-link" href="{{route('about_us')}}">About Us</a>
        <a class="text-white btn btn-link" href="{{route('faq')}}">FAQ</a>
    </div>
</footer>
